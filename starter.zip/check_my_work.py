import os
import sys
import subprocess
import io
from typing import Text
import calculator
from random import randint

default_stdout = sys.stdout
sys.stdout = buffer = io.StringIO()
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "colorama"])
sys.stdout = default_stdout

from colorama import Fore


def message_printer(passed, success_message, failure_message):
    if (passed):
        print(f"{Fore.GREEN}{success_message}{Fore.RESET}")
    else:
        print(f"{Fore.YELLOW}{failure_message}{Fore.RESET}")


def printed_list_finder(input_list)->str:
    value1 = input_list.find("[")
    value2 = input_list.find("]") + 1
    return input_list[value1:value2]


if (int(sys.argv[1]) == 1):
    print(Fore.RED)
    output = [i.strip('\n') for i in os.popen('python -c "import sorting; sorting.sort_students()"')]
    print(Fore.RESET)
    expected_value1 = "['3454', '6342', '5846', '4686']"
    expected_value2 = "['1243', '3455', '6477', '7355', '2647', '8453']"
    if (len(output) != 0):
        actual_value1 = printed_list_finder(output[0])
        actual_value2 = printed_list_finder(output[1])
        message_printer((expected_value1 == actual_value1) & (expected_value2 == actual_value2), 
        "You have successfully resolved the logical error in the code!", 
        "You have NOT correctly solved the logical error in the code.")
    else:
        print("You have NOT correctly solved the logical error in the code.")

if(int(sys.argv[1]) == 2):
    caught_exception = False
    try:
        calculator.division_calculator(5, 0)
    except ZeroDivisionError as e:
        print(f"A {e} was caused, but was handled.")
        caught_exception = True
    message_printer(caught_exception, 
    "You have successfully wrote code which may cause a ZeroDivisionError.", 
    "You have NOT correctly wrote code which may cause a ZeroDivisionError.")

if(int(sys.argv[1]) == 3):
    message_printer((calculator.division_calculator2(5, 0) == -1), 
    "You have successfully refactored the division_calculator() function to handle ZeroDivisionErrors.", 
    "You have NOT correctly refactored the division_calculator() function to hanlde ZeroDivisionErrors.")

if(int(sys.argv[1]) == 4):
    student_reg_output = [i.strip('\n') for i in os.popen('python -c "import student_registration; student_registration.register_students()"')]
    if(len(student_reg_output) != 0):
        message_printer((student_reg_output[0].find("FileNotFoundError")) | (student_reg_output[0].find("PermissionError")), 
        "You have succesfully wrote code which handles multiple exceptions.", 
        "You have NOT correctly written code which handles multiple exceptions.")
    else:
        print("You have NOT correctly written code which handles multiple exceptions.")

