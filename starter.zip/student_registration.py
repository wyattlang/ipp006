from students import get_students_from_file
from students import complete_registration

def register_students():
    students_list = []