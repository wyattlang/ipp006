
def division_calculator(num1, num2) -> int:
    pass
    
def division_calculator2(num1, num2) -> int:
    pass
